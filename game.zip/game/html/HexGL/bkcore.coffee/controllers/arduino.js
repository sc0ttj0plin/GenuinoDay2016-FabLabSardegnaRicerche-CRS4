var controller_ip_address = 'localhost';


function ArduinoRESTController(shipController) {
  var _self = this;

  _self.sc = shipController;
  _self.data = {left_button: 0, right_button: 0, power: 0};
  _self.address = controller_ip_address;

  //to arduino {speed: '0-700', light: 0-1}
  //from arduino {left_button: 0-1, right_button: 0-1: power: 0-1023}

  _self.callback = function() {

  }

  _self.init = function() {

      setInterval(function() {
        var speed = _self.sc.getRealSpeed()/_self.sc.arduinoBridge.scaleFactor*700;
        speed = Math.floor(speed);
        var led = speed >= 500 > 0 ? 1 : 0;
        _self.sendData(speed,led);
      },100);

  }

  _self.sendData = function(speed, led) {
    console.log("speed", speed, "boost", led);
    $.ajax({
      type: 'GET',
      dataType: "json",
      url: "http://" + _self.address + "?speed="+speed+"&boost="+led,
      success: function (responseData, textStatus, jqXHR) {
        console.log("data", responseData);
        _self.data = responseData;
        _self.callback(_self.data);
      },
      error: function (responseData, textStatus, errorThrown) {
          console.log("error");
          console.log(responseData);
          console.log(textStatus);
          console.log(errorThrown);
      }
    });
  }

}

function ArduinoWSController(shipController) {
  var _self = this;

  _self.sc = shipController;
  _self.data = {left_button: 0, right_button: 0, power: 0};
  _self.address = controller_ip_address;
  _self.socket = null;

  //to arduino {speed: '0-700', light: 0-1}
  //from arduino {left_button: 0-1, right_button: 0-1: power: 0-1023}

  _self.sendState = function() {
    var speed = _self.sc.getRealSpeed()/_self.sc.arduinoBridge.scaleFactor*700;
    speed = Math.floor(speed);
    console.log(speed);
    var led = speed >= 500 > 0 ? 1 : 0;
    var data = {speed: speed, led: led};
    _self.socket.send("?speed="+speed+"&boost="+led);
    
  }

  _self.init = function() {

    setInterval(
      function() {
        if(!_self.socket) {
          _self.connect();
        }
      }, 1000);
  }

  _self.connect = function() {
    _self.socket = new WebSocket("ws://" + _self.address);

      _self.socket.onopen = function(event) {
        console.log("WebSocket - Open");
      };

      _self.socket.onmessage = function(event) {
        var message = JSON.parse(event.data);
        console.log(message);
        _self.data = message;
        _self.callback(_self.data);
        _self.sendState();
      };

      _self.socket.onerror = function(error) {
        console.log("WebSocket - Error");

        setTimeout(function() {
          _self.init();
        }, 1000);
      };

      _self.socket.onclose = function(error) {
        console.log("WebSocket - Close");

        setTimeout(function() {
          _self.init();
        }, 1000);
      };
  }

}


